//
//  PickYourTableViewController.swift
//  ReserveYoSelf
//
//  Created by Olivia Ayala on 3/12/18.
//  Copyright © 2018 iOSfinal. All rights reserved.
//

import UIKit

class PickYourTableViewController: UIViewController {

    @IBOutlet var tableButtons: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
